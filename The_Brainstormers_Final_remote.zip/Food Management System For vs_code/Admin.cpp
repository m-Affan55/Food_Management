#include "Admin.h"
#include<limits>

void Admin::AdminMenu()
{
	std::string admin = "";

	do {
		system("cls");
		PrintTitle::printTitle();

		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "Admin Menu!" << "\033[32m" << "              |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "1.Add User! " << "\033[32m" << "             |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "2.Delete User!" << "\033[32m" << "           |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "3.View All Users!" << "\033[32m" << "        |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "4.View Logs!" << "\033[32m" << "             |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "5.Sign Out!!" << "\033[32m" << "             |" << "\033[0m" << '\n';

		std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		if (admin != "1" && admin != "2" && admin != "3" && admin != "4" && admin != "5" && admin != "")
		{
			std::cout << "\033[32m" << "|        Select a valid option!        |" << "\033[0m" << '\n';
			std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		}
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';

		getline(std::cin, admin);
	} while (admin != "1" && admin != "2" && admin != "3" && admin != "4" && admin != "5");
	option = admin;
}

void Admin::addUser()
{
	std::string username;
	std::string password;
	std::string role;
	bool usernameRepeat = false;
	system("cls");

	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|              " << "\033[31m" << "Add User!" << "\033[32m" << "               |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|  " << "\033[31m" << "Enter user username: " << "\033[32m" << "               |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|  " << "\033[31m" << "Enter your password: " << "\033[32m" << "               |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|  " << "\033[31m" << "Select Role   " << "\033[32m" << "                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|  " << "\033[31m" << "1.Manager        " << "\033[32m" << "                   |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|  " << "\033[31m" << "2.Chef           " << "\033[32m" << "                   |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|  " << "\033[31m" << "3.Sales Employee " << "\033[32m" << "                   |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';


	std::cout << "" << '\n';

	do {

		if (usernameRepeat)
		{
			PrintTitle::gotoxy(3, 16);
			std::cout << '\n';
			std::cout << "\033[34m" << "        Username Already Exists!        " << "\033[0m" << '\n';
			PrintTitle::gotoxy(3, 5);
			std::cout << "                             ";
		}
		usernameRepeat = false;

		PrintTitle::gotoxy(3, 5);
		std::getline(std::cin, username);

		for (int i = 0; i < User::users.size(); i++)
		{
			if (username == User::users[i].username)
			{
				usernameRepeat = true;
			}
		}
	} while (usernameRepeat);

	PrintTitle::gotoxy(3, 7);
	std::getline(std::cin, password);
	role = "1";
	do {
		if (role != "1" && role != "2" && role != "3")
		{
			PrintTitle::gotoxy(3, 14);
			std::cout << "\033[34m" << "Enter valid Role!" << "\033[0m" << '\n';
			PrintTitle::gotoxy(3, 13);
			std::cout << "                         ";
		}
		PrintTitle::gotoxy(3, 13);
		std::getline(std::cin, role);

	} while (role != "1" && role != "2" && role != "3");

	int x = stoi(role);
	switch (x)
	{
	case 1:role = "Manager"; break;
	case 2: role = "Chef"; break;
	case 3: role = "Sales Employee"; break;
	}

	User u(username, password, role);
	User::users.push_back(u);
	logActivity("Admin added new employee: " + username + " with role: " + role);
	PrintTitle::gotoxy(3, 16);
	std::cout << '\n';
	std::cout << "\033[34m" << "        User Added Successfully!        " << "\033[0m" << '\n';
}

void Admin::deleteUser()
{
	std::string username;
	bool exists = false;
	std::string deletedRole = "";

	viewUsers();

	PrintTitle::gotoxy(65, 0);
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 1);
	std::cout << "\033[32m" << "|             " << "\033[31m" << "Delete User!" << "\033[32m" << "             |" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 2);
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 3);
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 4);
	std::cout << "\033[32m" << "|  " << "\033[31m" << "Enter username: " << "\033[32m" << "                    |" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 5);
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 6);
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';


	PrintTitle::gotoxy(68, 5);
	std::getline(std::cin, username);
	for (int i = 0; i < User::users.size(); i++)
	{
		if (User::users[i].username == username)
		{
			if (User::users[i].role == "Admin")
			{
				PrintTitle::gotoxy(68, 7);
				std::cout << "\033[34m" << "        Admin can not be deleted        " << "\033[0m" << '\n';
				PrintTitle::gotoxy(68, 8);
				return;
			}
			exists = true;
			deletedRole = User::users[i].role;
			
			User temp;
			temp = User::users[i];
			User::users[i] = User::users[User::users.size() - 1];
			User::users[User::users.size() - 1] = temp;
			User::users.pop_back();
			break;
		}
	}

	if (!exists)
	{
		PrintTitle::gotoxy(68, 7);
		std::cout << "\033[34m" << "        Invalid Username!        " << "\033[0m" << '\n';
	}
	else
	{
		PrintTitle::gotoxy(68, 7);
		std::cout << "\033[34m" << "        Delete succesfully!        " << "\033[0m" << '\n';
		logActivity("Admin deleted employee: " + username + " with role: " + deletedRole);
	}
	PrintTitle::gotoxy(68, 8);
}

void Admin::viewUsers()
{
	system("cls");
	std::cout << "\033[32m" << "+------------------------+--------------+------------------+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(22) << "User"
		<< "\033[32m" << " | " << "\033[31m"<< std::left << std::setw(12) << "Password"
		<< "\033[32m" << " | " << "\033[31m"<< std::left << std::setw(16) << "Role" << "\033[32m" << " |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+------------------------+--------------+------------------+" << "\033[0m" << '\n';
	for (int i = 0; i < User::users.size(); i++)
	{
		std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(22) << User::users[i].username << "\033[32m" << " | " << "\033[31m" << std::left << std::setw(12) << User::users[i].password << "\033[32m" << " | " << "\033[31m" << std::left << std::setw(16) << User::users[i].role << "\033[32m" << " |" << "\033[0m" << '\n';
	}
	std::cout << "\033[32m" << "+------------------------+--------------+------------------+" << "\033[0m" << '\n';
}

void Admin::viewLogs()
{
	system("cls");
	std::cout << "\033[34m" << "--- System Activity Logs ---" << '\n';
	std::ifstream logFile("activity_log.txt");
	
	if (!logFile.is_open()) {
		std::cout << "\033[32m" << "Error: Unable to open activity_log.txt for reading." << '\n';
		std::cin.get();
		return;
	}

	std::string line;

	while (std::getline(logFile, line)) {
		std::cout << "\033[33m" << line << '\n';
	}
	logFile.close();
	std::cout << "\033[34m" << "--- End of Logs ---" << "\033[0m" << '\n';
}

void Admin::logActivity(const std::string& activity)
{
    std::ofstream logFile("activity_log.txt", std::ios::app);

    if (!logFile.is_open()) {
        std::cout << "Error: Unable to open activity_log.txt for writing." << '\n';
        return;
    }
    auto now = std::chrono::system_clock::now();
    std::time_t currentTime = std::chrono::system_clock::to_time_t(now);
    std::tm localTime;

    // The new, universal code
    std::tm* localTimePtr = std::localtime(&currentTime);
    localTime = *localTimePtr;

    logFile << "[" << std::put_time(&localTime, "%Y-%m-%d %H:%M:%S") << "] " << activity << '\n';
    logFile.close();
}