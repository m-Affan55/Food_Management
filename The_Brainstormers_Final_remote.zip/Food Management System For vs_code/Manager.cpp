#include "Manager.h"
#include "PrintTitle.h"


void Manager::logActivity(const std::string& activity)
{
    std::ofstream logFile("activity_log.txt", std::ios::app);

    if (!logFile.is_open()) {
        std::cout << "Error: Unable to open activity_log.txt for writing." << '\n';
        return;
    }
    auto now = std::chrono::system_clock::now();
    std::time_t currentTime = std::chrono::system_clock::to_time_t(now);
    std::tm localTime;

    // The new, universal code
    std::tm* localTimePtr = std::localtime(&currentTime);
    localTime = *localTimePtr;

    logFile << "[" << std::put_time(&localTime, "%Y-%m-%d %H:%M:%S") << "] " << activity << '\n';
    logFile.close();
}


void Manager::ManagerMenu()
{
	std::string managerChoice = "";
	do {
		system("cls");
		PrintTitle::printTitle();


		std::cout << "\033[32m" << "+========================================+" << "\033[0m" << '\n';


		std::cout << "\033[32m" << "|            " << "\033[31m" << "Manager Menu!" << "\033[32m" << "               |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "+========================================+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|                                        |" << "\033[0m" << '\n';


		std::cout << "\033[32m" << "|  " << "\033[31m" << "1.Request New Food" << std::string(36 - 18, ' ') << "\033[32m" << "  |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|  " << "\033[31m" << "2.Increase Stock" << std::string(36 - 16, ' ') << "\033[32m" << "  |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|  " << "\033[31m" << "3.View Requested Items" << std::string(36 - 22, ' ') << "\033[32m" << "  |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|  " << "\033[31m" << "4.View Main Menu" << std::string(36 - 16, ' ') << "\033[32m" << "  |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|  " << "\033[31m" << "5.Generate Sales Report" << std::string(36 - 23, ' ') << "\033[32m" << "  |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|  " << "\033[31m" << "6.View Daily Restock Suggestions" << std::string(36 - 32, ' ') << "\033[32m" << "  |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|  " << "\033[31m" << "7.Sign Out" << std::string(36 - 10, ' ') << "\033[32m" << "  |" << "\033[0m" << '\n';

		std::cout << "\033[32m" << "|                                        |" << "\033[0m" << '\n';

		if (!managerChoice.empty() && managerChoice != "1" && managerChoice != "2" && managerChoice != "3" && managerChoice != "4" && managerChoice != "5" && managerChoice != "6" && managerChoice != "7")
		{
			std::cout << "\033[32m" << "|       " << "\033[34m" << "Select a valid option!" << "\033[32m" << "       |" << "\033[0m" << '\n';
			std::cout << "\033[32m" << "|                                        |" << "\033[0m" << '\n';
		}
		else
		{
			std::cout << "\033[32m" << "|                                        |" << "\033[0m" << '\n';
			std::cout << "\033[32m" << "|                                        |" << "\033[0m" << '\n';
		}
		std::cout << "\033[32m" << "+========================================+" << "\033[0m" << '\n';
		std::cout << "\033[31m" << "Enter your choice: " << "\033[0m";
		std::getline(std::cin, managerChoice);
	} while (managerChoice != "1" && managerChoice != "2" && managerChoice != "3" && managerChoice != "4" && managerChoice != "5" && managerChoice != "6" && managerChoice != "7");
	option = managerChoice;
}



void Manager::requestItem()
{
	system("cls");
	std::string itemName, s_price, s_quantity, category;
	double price = 0.0;
	int quantity = 0;
	bool itemExists = false;

	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|        " << "\033[31m" << "Request New Food Item" << "\033[32m" << "         |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << "Enter Item Name: " << "\033[32m" << "                    |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << "Enter Price: " << "\033[32m" << "                        |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << "Enter Quantity: " << "\033[32m" << "                     |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << "Select Category:" << "\033[32m" << "                     |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << "1.Meal       2.Dessert    3.Drinks" << "\033[32m" << "   |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << "4.Appetizer  5.Fast Food" << "\033[32m" << "             |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << "Enter choice: " << "\033[32m" << "                       |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';

	do {
		if (itemExists) {
			PrintTitle::gotoxy(2, 14);
			std::cout << "\033[34m" << "    Item already exists! Try again.   " << "\033[0m" << '\n';
			PrintTitle::gotoxy(20, 4);
			std::cout << "                     ";
		}
		itemExists = false;
		PrintTitle::gotoxy(20, 4);
		std::getline(std::cin, itemName);
		for (const auto& food : FoodItem::requestedFoods) {
			if (food.itemName == itemName) itemExists = true;
		}
		for (const auto& food : FoodItem::foods) {
			if (food.itemName == itemName) itemExists = true;
		}
	} while (itemExists);
	PrintTitle::gotoxy(2, 14);
	std::cout << "                                      ";

	StringValidator str;
	PrintTitle::gotoxy(16, 5);
	std::getline(std::cin, s_price);
	while (str.stringNumberValidator(s_price)) {
		PrintTitle::gotoxy(2, 14);
		std::cout << "\033[34m" << "   Invalid price. Please enter digits.  " << "\033[0m" << '\n';
		PrintTitle::gotoxy(16, 5);
		std::cout << "                     ";
		PrintTitle::gotoxy(16, 5);
		std::getline(std::cin, s_price);
	}
	price = std::stod(s_price);
	PrintTitle::gotoxy(2, 14);
	std::cout << "                                      ";

	PrintTitle::gotoxy(19, 6);
	std::getline(std::cin, s_quantity);
	while (str.stringNumberValidator(s_quantity)) {
		PrintTitle::gotoxy(2, 14);
		std::cout << "\033[34m" << " Invalid quantity. Please enter digits. " << "\033[0m" << '\n';
		PrintTitle::gotoxy(19, 6);
		std::cout << "                     ";
		PrintTitle::gotoxy(19, 6);
		std::getline(std::cin, s_quantity);
	}
	quantity = std::stoi(s_quantity);
	PrintTitle::gotoxy(2, 14);
	std::cout << "                                      ";

	do {
		PrintTitle::gotoxy(17, 11);
		std::cout << "                     ";
		PrintTitle::gotoxy(17, 11);
		std::getline(std::cin, category);
		if (category != "1" && category != "2" && category != "3" && category != "4" && category != "5") {
			PrintTitle::gotoxy(2, 14);
			std::cout << "\033[34m" << "   Invalid category. Choose 1-5.    " << "\033[0m" << '\n';
		}
	} while (category != "1" && category != "2" && category != "3" && category != "4" && category != "5");

	int x = std::stoi(category);
	switch (x) {
	case 1: category = "Meal"; break;
	case 2: category = "Dessert"; break;
	case 3: category = "Drinks"; break;
	case 4: category = "Appetizer"; break;
	case 5: category = "Fast Food"; break;
	}

	FoodItem fooditem(itemName, price, quantity, category);
	FoodItem::requestedFoods.push_back(fooditem);
	logActivity("Manager requested new food item: " + itemName);
	PrintTitle::gotoxy(2, 14);
	std::cout << "\033[34m" << "     Food item requested successfully!    " << "\033[0m" << '\n';
}

void Manager::increaseStock()
{
	system("cls");
	viewMenuFoodItems();

	std::string foodItemName;
	std::string s_quantity;
	int quantity = 0;
	bool exists = false;
	int idx = 0;

	PrintTitle::gotoxy(65, 0);
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 1);
	std::cout << "\033[32m" << "|            " << "\033[31m" << "Increase Stock!" << "\033[32m" << "           |" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 2);
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 3);
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 4);
	std::cout << "\033[32m" << "|  " << "\033[31m" << "Enter food item: " << "\033[32m" << "                   |" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 5);
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 6);
	std::cout << "\033[32m" << "|  " << "\033[31m" << "Enter quantity: " << "\033[32m" << "                    |" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 7);
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	PrintTitle::gotoxy(65, 8);
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';


	PrintTitle::gotoxy(68, 5);
	std::getline(std::cin, foodItemName);

	for (size_t i = 0; i < FoodItem::foods.size(); ++i)
	{
		if (FoodItem::foods[i].itemName == foodItemName)
		{
			exists = true;
			idx = i;
			break;
		}
	}
	if (!exists)
	{
		PrintTitle::gotoxy(65, 9);
		std::cout << "\033[34m" << "Invalid food item!        " << "\033[0m" << '\n';
		PrintTitle::gotoxy(65, 10);
		return;
	}

	StringValidator str;
	bool inValid = false;
	do {
		if (inValid)
		{
			PrintTitle::gotoxy(65, 9);
			std::cout << "\033[34m" << "Enter valid quantity!        " << "\033[0m" << '\n';
			PrintTitle::gotoxy(65, 10);
			std::cout << "                             ";
		}
		PrintTitle::gotoxy(68, 7);
		std::cin >> s_quantity;
	} while (inValid = str.stringNumberValidator(s_quantity));

	quantity = std::stoi(s_quantity);
	FoodItem::foods[idx].quantity += quantity;
	if (exists)
	{
		logActivity("Manager increased stock for " + foodItemName + " by " + std::to_string(quantity) + ". New stock: " + std::to_string(FoodItem::foods[idx].quantity));
		PrintTitle::gotoxy(65, 9);
		std::cout << "\033[34m" << "Stock updated successfully!        " << "\033[0m" << '\n';
	}
	PrintTitle::gotoxy(65, 10);
}


void Manager::viewRequestedFoodItems()
{
	system("cls");
	std::cout << "\033[32m" << "+------------------------+-----------+------------------+------------------+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(22) << "Food Item"
		<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(9) << "Price"
		<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(16) << "Quantity"
		<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(16) << "Category" << "\033[32m" << " |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+------------------------+-----------+------------------+------------------+" << "\033[0m" << '\n';

	if (FoodItem::requestedFoods.empty()) {
		std::cout << "\033[32m" << "| " << "\033[31m" << "No requested food items found." << std::setw(49) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
	}
	else {
		for (const auto& item : FoodItem::requestedFoods) {
			std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(22) << item.itemName
				<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(9) << std::fixed << std::setprecision(2) << item.price
				<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(16) << item.quantity
				<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(16) << item.category
				<< "\033[32m" << " |" << "\033[0m" << '\n';
		}
	}
	std::cout << "\033[32m" << "+------------------------+-----------+------------------+------------------+" << "\033[0m" << '\n';
}

void Manager::viewMenuFoodItems()
{
	system("cls");
	std::cout << "\033[32m" << "+------------------------+-----------+------------------+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(22) << "Food Item"
		<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(9) << "Price"
		<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(16) << "Quantity" << "\033[32m" << " |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+------------------------+-----------+------------------+" << "\033[0m" << '\n';

	if (FoodItem::foods.empty()) {
		std::cout << "\033[32m" << "| " << "\033[31m" << "No food items found in the main menu." << std::setw(20) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
	}
	else {
		for (const auto& item : FoodItem::foods) {
			std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(22) << item.itemName
				<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(9) << std::fixed << std::setprecision(2) << item.price
				<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(16) << item.quantity
				<< "\033[32m" << " |" << "\033[0m" << '\n';
		}
	}
	std::cout << "\033[32m" << "+------------------------+-----------+------------------+" << "\033[0m" << '\n';
}

void Manager::viewSalesReport()
{
	system("cls");
	std::ifstream salesFile("sales.txt");
	std::vector<std::string> salesLines;
	std::string line;

	std::cout << "\033[32m" << "+=============================================================+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                         " << "\033[31m" << "Sales Report" << "\033[32m" << "                        |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+=============================================================+" << "\033[0m" << '\n';

	if (!salesFile.is_open()) {
		std::cout << "\033[32m" << "| " << "\033[31m" << "Unable to open sales.txt. No data available." << std::setw(15) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "+===============================================================+" << "\033[0m" << '\n';
		return;
	}

	while (std::getline(salesFile, line)) {
		salesLines.push_back(line);
	}
	salesFile.close();

	if (salesLines.empty()) {
		std::cout << "\033[32m" << "| " << "\033[31m" << "No sales data available yet." << std::setw(31) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "+===============================================================+" << "\033[0m" << '\n';
		return;
	}

	double totalRevenue = 0.0;
	std::map<std::string, int> totalItemsSold;

	std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(38) << "Order Details" << "\033[32m" << " | " << "\033[31m" << std::setw(18) << "Total Amount (PKR)" << "\033[32m" << " |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+----------------------------------------+--------------------+" << "\033[0m" << '\n';

	for (const std::string& salesLine : salesLines) {
		if (salesLine.empty()) continue;

		std::stringstream ss(salesLine);
		std::string segment, orderItemsSummary;
		double currentOrderTotal = 0.0;
		std::vector<std::string> itemSegments;
		while (std::getline(ss, segment, ',')) itemSegments.push_back(segment);

		if (!itemSegments.empty()) {
			try {
				currentOrderTotal = std::stod(itemSegments.back());
				itemSegments.pop_back();
			}
			catch (const std::exception&) { currentOrderTotal = 0.0; }
		}

		for (const std::string& itemDetail : itemSegments) {
			std::stringstream itemSs(itemDetail);
			std::string name, s_price, s_quantity;
			if (std::getline(itemSs, name, ';') && std::getline(itemSs, s_price, ';') && std::getline(itemSs, s_quantity, ';')) {
				try {
					totalItemsSold[name] += std::stoi(s_quantity);
					if (!orderItemsSummary.empty()) orderItemsSummary += ", ";
					orderItemsSummary += name + " (x" + s_quantity + ")";
				}
				catch (const std::exception&) {}
			}
		}
		totalRevenue += currentOrderTotal;
		std::string displaySummary = orderItemsSummary;
		if (displaySummary.length() > 38) displaySummary = displaySummary.substr(0, 35) + "...";

		std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(38) << displaySummary
			<< "\033[32m" << " | " << "\033[31m" << std::right << std::setw(18) << std::fixed << std::setprecision(2) << currentOrderTotal
			<< "\033[32m" << " |" << "\033[0m" << '\n';
	}
	std::cout << "\033[32m" << "+----------------------------------------+--------------------+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << std::setw(59) << " " << " |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[34m" << "--- Summary ---" << std::setw(44) << " " << "\033[32m" << " |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[33m" << std::left << std::setw(20) << "Total Revenue: " << std::fixed << std::setprecision(2) << totalRevenue << " PKR" << std::setw(20) << " " << "\033[32m" << "        |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[33m" << "Total Items Sold (by type):" << std::setw(31) << " " << "\033[32m" << "  |" << "\033[0m" << '\n';

	if (totalItemsSold.empty()) {
		std::cout << "\033[32m" << "| " << "\033[33m" << "  No items recorded." << std::setw(41) << " " << "\033[32m" << " |" << "\033[0m" << '\n';
	}
	else {
		for (const auto& pair : totalItemsSold) {
			std::string itemLine = "  - " + pair.first + ": " + std::to_string(pair.second) + " units";
			std::cout << "\033[32m" << "| " << "\033[33m" << std::left << std::setw(58) << itemLine << "\033[32m" << "  |" << "\033[0m" << '\n';
		}
	}
	std::cout << "\033[32m" << "+=============================================================+" << "\033[0m" << '\n';
}

void Manager::dailyRestockSuggestion()
{
	system("cls");
	PrintTitle::printTitle();

	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|       " << "\033[31m" << "Daily Restock Suggestions" << "\033[32m" << "      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';

	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';

	if (FoodItem::foods.empty()) {
		std::cout << "\033[32m" << "| " << "\033[31m" << "No food items in menu to check for stock." << std::setw(6) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		logActivity("Manager viewed daily restock suggestion (no items in menu).");
		std::cout << "Press Enter to continue...";
		std::cin.get();
		return;
	}

	const int LOW_STOCK_THRESHOLD = 5;

	std::vector<FoodItem> lowStockItems;
	for (const auto& item : FoodItem::foods) {
		if (item.quantity <= LOW_STOCK_THRESHOLD) {
			lowStockItems.push_back(item);
		}
	}

	if (lowStockItems.empty()) {
		std::cout << "\033[32m" << "| " << "\033[31m" << "All items are adequately stocked!" << std::setw(10) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "| (Above " << LOW_STOCK_THRESHOLD << " units) " << std::setw(20) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
	}
	else {

		std::sort(lowStockItems.begin(), lowStockItems.end(),
			[](const FoodItem& a, const FoodItem& b) {
				return a.quantity < b.quantity;
			});


		std::cout << "\033[32m" << "+------------------------+-------------+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(22) << "Low Stock Item"
			<< "\033[32m" << " | " << "\033[31m" << std::left << std::setw(10) << "Quantity" << "\033[32m" << "  |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "+------------------------+-------------+" << "\033[0m" << '\n';

		for (const auto& item : lowStockItems) {
			std::string itemNameLimited = item.itemName;
			if (itemNameLimited.length() > 22) {
				itemNameLimited = itemNameLimited.substr(0, 19) + "...";
			}
			std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(22) << itemNameLimited
				<< "\033[32m" << " | " << "\033[31m" << std::right << std::setw(10) << item.quantity
				<< "\033[32m" << "  |" << "\033[0m" << '\n';
		}
		std::cout << "\033[32m" << "+------------------------+-------------+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "| " << "\033[34m" << "Consider restocking the above items." << std::setw(1) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
	}

	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	logActivity("Manager viewed daily restock suggestion.");

}