#pragma once
#include<iostream>
#include<iomanip>
#include<string>
#include<fstream>
#include<chrono>
#include<ctime>

#include"User.h"
#include"PrintTitle.h"
class Admin
{
public:
	void AdminMenu();
	void addUser();
	void deleteUser();
	void viewUsers();
	void viewLogs();
	void logActivity(const std::string& activity);

	std::string option;
private:

};