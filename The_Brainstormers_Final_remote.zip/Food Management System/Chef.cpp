#include "Chef.h"
#include "PrintTitle.h"
#include <limits>

void Chef::ChefMenu()
{
	std::string chefChoice = "";
	do {
		system("cls");
		PrintTitle::printTitle();
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|              " << "\033[31m" << "Chef Menu!" << "\033[32m" << "              |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|      " << "\033[31m" << "1. View All Requests" << "\033[32m" << "            |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|      " << "\033[31m" << "2. Add Recipe" << "\033[32m" << "                   |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|      " << "\033[31m" << "3. View Menu & Recipes" << "\033[32m" << "          |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|      " << "\033[31m" << "4. Edit Recipe" << "\033[32m" << "                  |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|      " << "\033[31m" << "5. Sign Out" << "\033[32m" << "                     |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';

		if (!chefChoice.empty() && chefChoice != "1" && chefChoice != "2" && chefChoice != "3" && chefChoice != "4" && chefChoice != "5") {
			std::cout << "\033[32m" << "|        Select a valid option!        |" << "\033[0m" << '\n';
			std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		}
		else {
			std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
			std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		}
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		std::cout << "\033[31m" << "Enter your choice: " << "\033[0m";
		std::getline(std::cin, chefChoice);
	} while (chefChoice != "1" && chefChoice != "2" && chefChoice != "3" && chefChoice != "4" && chefChoice != "5");
	option = chefChoice;
}

void Chef::AddRecipe()
{
	Manager::viewRequestedFoodItems();

	std::string itemName;
	int idx = -1;

	PrintTitle::gotoxy(80, 0);
	std::cout << "\033[32m" << "+======================================+" << "\033[0m";
	PrintTitle::gotoxy(80, 1);
	std::cout << "\033[32m" << "|           " << "\033[31m" << "Add a Recipe" << "\033[32m" << "               |" << "\033[0m";
	PrintTitle::gotoxy(80, 2);
	std::cout << "\033[32m" << "+======================================+" << "\033[0m";
	PrintTitle::gotoxy(80, 3);
	std::cout << "\033[32m" << "| " << "\033[31m" << "Enter Item Name: " << "\033[32m" << "                    |" << "\033[0m";
	PrintTitle::gotoxy(80, 4);
	std::cout << "\033[32m" << "|                                      |" << "\033[0m";
	PrintTitle::gotoxy(80, 5);
	std::cout << "\033[32m" << "+======================================+" << "\033[0m";

	while (idx == -1) {
		PrintTitle::gotoxy(82, 4);
		std::cout << "                                    ";
		PrintTitle::gotoxy(100, 3);
		std::getline(std::cin, itemName);
		for (int i = 0; i < FoodItem::requestedFoods.size(); i++) {
			if (FoodItem::requestedFoods[i].itemName == itemName) {
				idx = i;
				break;
			}
		}
		if (idx == -1) {
			PrintTitle::gotoxy(82, 4);
			std::cout << "\033[34m" << "      Invalid food item name!       " << "\033[0m";
		}
	}

	system("cls");
	std::cout << "\033[32m" << "+====================================================+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|          " << "\033[31m" << "Creating Recipe for: " << std::left << std::setw(19) << itemName << "\033[32m" << "  |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+====================================================+" << "\033[0m" << '\n';

	StringValidator str;
	std::string s_size;
	int size;

	std::cout << "\033[31m" << "Enter Number of ingredients: " << "\033[0m";
	std::getline(std::cin, s_size);
	while (str.stringNumberValidator(s_size)) {
		std::cout << "\033[34m" << "Invalid input. Please enter a number: " << "\033[0m";
		std::getline(std::cin, s_size);
	}
	size = stoi(s_size);

	std::vector<std::string> ingredients;
	for (int i = 0; i < size; i++) {
		std::cout << "\033[31m" << "Enter ingredient no. " << i + 1 << ": " << "\033[0m";
		std::string ing;
		getline(std::cin, ing);
		ingredients.push_back(ing);
	}

	std::cout << "\033[31m" << "Enter Number of steps: " << "\033[0m";
	std::getline(std::cin, s_size);
	while (str.stringNumberValidator(s_size)) {
		std::cout << "\033[34m" << "Invalid input. Please enter a number: " << "\033[0m";
		std::getline(std::cin, s_size);
	}
	size = stoi(s_size);

	std::vector<std::string> steps;
	for (int i = 0; i < size; i++) {
		std::cout << "\033[31m" << "Enter step no. " << i + 1 << ": " << "\033[0m";
		std::string s;
		getline(std::cin, s);
		steps.push_back(s);
	}

	Recipe recipe(ingredients, steps, itemName);
	Recipe::recipes.push_back(recipe);

	FoodItem temp = FoodItem::requestedFoods[idx];
	FoodItem::foods.push_back(temp);
	FoodItem::requestedFoods.erase(FoodItem::requestedFoods.begin() + idx);

	std::cout << "\n\033[34m" << "Recipe for '" << itemName << "' added and item moved to main menu." << "\033[0m" << '\n';
}

void Chef::viewItemsWithQuantityAndRecipe()
{
	system("cls");
	std::cout << "\033[32m" << "+------------------------+------------+--------------------------------+--------------------------------+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(22) << "Food Item" << "\033[32m" << " | " << "\033[31m" << std::setw(10) << "Quantity" << "\033[32m" << " | " << "\033[31m" << std::setw(30) << "Ingredients" << "\033[32m" << " | " << "\033[31m" << std::setw(30) << "Steps" << "\033[32m" << " |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+------------------------+------------+--------------------------------+--------------------------------+" << "\033[0m" << '\n';

	if (FoodItem::foods.empty()) {
		std::cout << "\033[32m" << "| " << "\033[31m" << "No items in the main menu." << std::setw(91) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
	}
	else {
		for (const auto& food : FoodItem::foods) {
			std::string ingredientsStr, stepsStr;
			bool recipeFound = false;
			for (const auto& recipe : Recipe::recipes) {
				if (food.itemName == recipe.itemName) {
					recipeFound = true;
					for (size_t k = 0; k < recipe.ingredients.size(); ++k) {
						ingredientsStr += std::to_string(k + 1) + "." + recipe.ingredients[k] + " ";
					}
					for (size_t k = 0; k < recipe.steps.size(); ++k) {
						stepsStr += std::to_string(k + 1) + "." + recipe.steps[k] + " ";
					}
					break;
				}
			}
			if (!recipeFound) {
				ingredientsStr = "No recipe found.";
				stepsStr = "No recipe found.";
			}
			if (ingredientsStr.length() > 28) ingredientsStr = ingredientsStr.substr(0, 25) + "...";
			if (stepsStr.length() > 28) stepsStr = stepsStr.substr(0, 25) + "...";

			std::cout << "\033[32m" << "| " << "\033[31m" << std::left << std::setw(22) << food.itemName << "\033[32m" << " | " << "\033[31m" << std::setw(10) << food.quantity << "\033[32m" << " | " << "\033[31m" << std::setw(30) << ingredientsStr << "\033[32m" << " | " << "\033[31m" << std::setw(30) << stepsStr << "\033[32m" << " |" << "\033[0m" << '\n';
		}
	}
	std::cout << "\033[32m" << "+------------------------+------------+--------------------------------+--------------------------------+" << "\033[0m" << '\n';
}

void Chef::viewAllRecipes()
{
	system("cls");
	std::cout << "\033[32m" << "+====================================================+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                " << "\033[31m" << "All Available Recipes" << "\033[32m" << "               |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+====================================================+" << "\033[0m" << '\n';

	if (Recipe::recipes.empty()) {
		std::cout << "\033[32m" << "| " << "\033[31m" << "No recipes currently available." << std::setw(26) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
	}
	else {
		for (const auto& recipe : Recipe::recipes) {
			std::cout << "\033[32m" << "| " << "\033[31m" << "Recipe for: " << std::left << std::setw(38) << recipe.itemName << "\033[32m" << " |" << "\033[0m" << '\n';
			std::cout << "\033[32m" << "+----------------------------------------------------+" << "\033[0m" << '\n';
			std::cout << "\033[32m" << "| " << "\033[34m" << "Ingredients:" << std::setw(39) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
			if (recipe.ingredients.empty()) {
				std::cout << "\033[32m" << "|   " << "\033[33m" << "(None)" << std::setw(44) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
			}
			else {
				for (size_t j = 0; j < recipe.ingredients.size(); ++j) {
					std::string ingredientLine = "  " + std::to_string(j + 1) + ". " + recipe.ingredients[j];
					std::cout << "\033[32m" << "| " << "\033[33m" << std::left << std::setw(50) << ingredientLine << "\033[32m" << " |" << "\033[0m" << '\n';
				}
			}
			std::cout << "\033[32m" << "| " << "\033[34m" << "Steps:" << std::setw(45) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
			if (recipe.steps.empty()) {
				std::cout << "\033[32m" << "|   " << "\033[33m" << "(None)" << std::setw(44) << " " << "\033[32m" << "|" << "\033[0m" << '\n';
			}
			else {
				for (size_t j = 0; j < recipe.steps.size(); ++j) {
					std::string stepLine = "  " + std::to_string(j + 1) + ". " + recipe.steps[j];
					std::cout << "\033[32m" << "| " << "\033[33m" << std::left << std::setw(50) << stepLine << "\033[32m" << " |" << "\033[0m" << '\n';
				}
			}
			std::cout << "\033[32m" << "+====================================================+" << "\033[0m" << '\n';
		}
	}
}

void Chef::editRecipe()
{
	viewAllRecipes();
	std::string itemName;
	int recipeIdx = -1;

	PrintTitle::gotoxy(60, 0); std::cout << "\033[32m+======================================+\033[0m";
	PrintTitle::gotoxy(60, 1); std::cout << "\033[32m|           \033[31mEdit a Recipe\033[32m              |\033[0m";
	PrintTitle::gotoxy(60, 2); std::cout << "\033[32m+======================================+\033[0m";
	PrintTitle::gotoxy(60, 3); std::cout << "\033[32m| \033[31mItem Name to Edit: \033[32m                  |\033[0m";
	PrintTitle::gotoxy(60, 4); std::cout << "\033[32m|                                      |\033[0m";
	PrintTitle::gotoxy(60, 5); std::cout << "\033[32m+======================================+\033[0m";

	while (recipeIdx == -1) {
		PrintTitle::gotoxy(62, 4); std::cout << "                                    ";
		PrintTitle::gotoxy(81, 3); std::cout << "               ";
		PrintTitle::gotoxy(81, 3);
		std::getline(std::cin, itemName);
		if (itemName.empty()) continue;
		for (size_t i = 0; i < Recipe::recipes.size(); ++i) {
			if (Recipe::recipes[i].itemName == itemName) {
				recipeIdx = i;
				break;
			}
		}
		if (recipeIdx == -1) {
			PrintTitle::gotoxy(62, 4);
			std::cout << "\033[34m Recipe not found! Try again!\033[0m";
			_getch();
		}
	}

	system("cls");
	Recipe& existingRecipe = Recipe::recipes[recipeIdx];

	std::cout << "\033[32m+====================================================+\033[0m" << '\n';
	std::cout << "\033[32m|              \033[31mEditing Recipe for: " << std::left << std::setw(18) << itemName << "\033[32m|" << '\n';
	std::cout << "\033[32m+====================================================+\033[0m" << '\n';

	std::cout << "\n\033[36m" << "-- Current Ingredients --" << "\033[0m" << '\n';
	if (existingRecipe.ingredients.empty()) std::cout << "  (None)\n";
	else for (size_t i = 0; i < existingRecipe.ingredients.size(); ++i) std::cout << "  " << i + 1 << ". " << existingRecipe.ingredients[i] << '\n';

	std::cout << "\n\033[31m" << "Enter NEW ingredients (type 'done' to finish):" << "\033[0m" << '\n';
	std::vector<std::string> newIngredients;
	std::string inputLine;
	while (true) {
		std::cout << " > ";
		std::getline(std::cin, inputLine);
		if (inputLine == "done") break;
		if (!inputLine.empty()) newIngredients.push_back(inputLine);
	}
	if (!newIngredients.empty()) {
		existingRecipe.ingredients = newIngredients;
	}

	std::cout << "\n\033[36m" << "-- Current Steps --" << "\033[0m" << '\n';
	if (existingRecipe.steps.empty()) std::cout << "  (None)\n";
	else for (size_t i = 0; i < existingRecipe.steps.size(); ++i) std::cout << "  " << i + 1 << ". " << existingRecipe.steps[i] << '\n';

	std::cout << "\n\033[31m" << "Enter NEW steps (type 'done' to finish):" << "\033[0m" << '\n';
	std::vector<std::string> newSteps;
	while (true) {
		std::cout << " > ";
		std::getline(std::cin, inputLine);
		if (inputLine == "done") break;
		if (!inputLine.empty()) newSteps.push_back(inputLine);
	}
	if (!newSteps.empty()) {
		existingRecipe.steps = newSteps;
	}

	std::cout << "\n\033[34m" << "Recipe for '" << itemName << "' updated successfully." << "\033[0m" << '\n';
}
