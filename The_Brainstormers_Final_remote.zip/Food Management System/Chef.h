#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<conio.h>

#include"Manager.h"
#include"StringValidator.h"
#include"Recipe.h"

class Chef
{
public:
	void ChefMenu();
	void AddRecipe();
	void viewItemsWithQuantityAndRecipe();
	void viewAllRecipes();
	void editRecipe();

	std::string option;
private:

};

