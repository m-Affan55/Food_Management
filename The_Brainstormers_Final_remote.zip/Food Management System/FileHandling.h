#pragma once
#include<iostream>
#include<fstream>

class FileHandling
{
public:
	std::string getField(std::string record, int field)
	{
		int commaCount = 0;
		std::string result;
		for (int i = 0; record[i] != '\0'; i++)
		{
			if (record[i] == ',')
			{
				commaCount++;
				continue;
			}
			if (commaCount == field)
			{
				result += record[i];
			}
		}
		return result;
	}
};