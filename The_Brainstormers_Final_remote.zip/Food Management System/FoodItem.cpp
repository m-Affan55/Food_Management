#include "FoodItem.h"

FoodItem::FoodItem(std::string itmeName, double price, int quantity, std::string category)
{
	this->itemName = itmeName;
	this->price = price;
	this->quantity = quantity;
	this->category = category;
}

FoodItem::FoodItem(std::string itmeName, double price, int quantity)
{
	this->itemName = itmeName;
	this->price = price;
	this->quantity = quantity;
}

FoodItem::FoodItem(std::string itmeName)
{
	this->itemName = itmeName;
}

FoodItem::FoodItem()
{
}

void FoodItem::loadRequestedFoodItemsFromFile(std::string filename)
{
	requestedFoods.clear();
	std::string record = "";

	std::fstream file;
	file.open(filename, std::ios::in);
	while (getline(file, record))
	{
		FileHandling get;
		std::string itemName = get.getField(record, 0);
		double price = std::stod(get.getField(record, 1));
		int quantity = std::stoi(get.getField(record, 2));
		std::string category = get.getField(record, 3);
		
		FoodItem food(itemName,price,quantity,category);
		requestedFoods.push_back(food);
	}
	file.close();
}

void FoodItem::writeRequestedFoodItemsToFile(std::string filename)
{
	std::string record;

	std::fstream file;
	file.open(filename, std::ios::out);
	for (int i = 0; i < requestedFoods.size(); i++)
	{
		record = "";
		record += requestedFoods[i].itemName;
		record += ",";
		record += std::to_string(requestedFoods[i].price);
		record += ",";
		record += std::to_string(requestedFoods[i].quantity);
		record += ",";
		record += requestedFoods[i].category;
		record += "\n";
		file << record;
	}
	file.close();
}

void FoodItem::loadMenuFoodItemsFromFile(std::string filename)
{
	foods.clear();
	std::string record = "";

	std::fstream file;
	file.open(filename, std::ios::in);
	while (getline(file, record))
	{
		FileHandling get;
		std::string itemName = get.getField(record, 0);
		double price = std::stod(get.getField(record, 1));
		int quantity = std::stoi(get.getField(record, 2));

		FoodItem food(itemName, price, quantity);
		foods.push_back(food);
	}
	file.close();
}

void FoodItem::writeMenuFoodItemsToFile(std::string filename)
{
	std::string record;

	std::fstream file;
	file.open(filename, std::ios::out);
	for (int i = 0; i < foods.size(); i++)
	{
		record = "";
		record += foods[i].itemName;
		record += ",";
		record += std::to_string(foods[i].price);
		record += ",";
		record += std::to_string(foods[i].quantity);
		record += "\n";
		file << record;
	}
	file.close();
}

std::vector<FoodItem> FoodItem::foods = {};
std::vector<FoodItem> FoodItem::requestedFoods = {};