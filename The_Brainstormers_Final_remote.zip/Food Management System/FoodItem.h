#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<fstream>

#include"FileHandling.h"

class FoodItem
{
public:
	static std::vector<FoodItem> foods;
	static std::vector<FoodItem> requestedFoods;

	static void loadRequestedFoodItemsFromFile(std::string filename);
	static void writeRequestedFoodItemsToFile(std::string filename);

	static void loadMenuFoodItemsFromFile(std::string filename);
	static void writeMenuFoodItemsToFile(std::string filename);

	std::string itemName;
	double price;
	int quantity;
	std::string category;

	FoodItem(std::string itmeName,double price,int quantity,std::string category);
	FoodItem(std::string itmeName, double price, int quantity);
	FoodItem(std::string itmeName);
	FoodItem();
private:

};

