#include "Login.h"

std::string Login::login()
{
	std::string login = "";
	do {
		system("cls");
		PrintTitle::printTitle();

		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "Login Page!" << "\033[32m" << "              |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "1. SignIn " << "\033[32m" << "               |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "2. Exit   " << "\033[32m" << "               |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		if (login != "1" && login != "2" && login != "")
		{
			std::cout << "\033[32m" << "|        Select a valid option!        |" << "\033[0m" << '\n';
			std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		}
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		getline(std::cin, login);
	} while (login!="1" && login!="2");
	return login;
}

User Login::SignIn()
{
	std::string username;
	std::string password;

	system("cls");

	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                " << "\033[31m" << "SignIn!" << "\033[32m" << "               |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|  " << "\033[31m" << "Enter your username: " << "\033[32m" << "               |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|  " << "\033[31m" << "Enter your password: " << "\033[32m" << "               |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
	std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';

	PrintTitle::gotoxy(3, 5);
	std::getline(std::cin, username);
	PrintTitle::gotoxy(3, 7);
	std::getline(std::cin, password);

	for (int i = 0; i < User::users.size(); i++)
	{
		if (User::users[i].username == username && User::users[i].password == password)
		{
			return User::users[i];
		}
	}

	PrintTitle::gotoxy(3, 9);
	std::cout << "\n";
	std::cout << "\033[34m" << "        Incorrect Username or Password!         "<< "\033[0m" << '\n';
	std::cout << "\033[34m" << "Press any key to try again and \'b\' to go back!"<< "\033[0m" << '\n';
	if (_getch() == 'b')
	{
		return User("exit");
	}
	return SignIn();
}
