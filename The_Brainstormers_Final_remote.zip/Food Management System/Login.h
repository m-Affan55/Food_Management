#pragma once
#include<iostream>
#include<string>
#include<conio.h>

#include"User.h"
#include"PrintTitle.h"

class Login
{
public:
	static std::string login();
	static User SignIn();
private:
};

