#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <sstream>
#include <map>
#include <chrono>
#include <ctime>
#include <limits>
#include <fstream>
#include <exception>
#include <algorithm>

#include "FoodItem.h"
#include "StringValidator.h" 

class Manager
{
public:
    void ManagerMenu();
    void requestItem();
    void increaseStock();
    void viewSalesReport();
    void logActivity(const std::string& activity);
    static void viewRequestedFoodItems();
    static void viewMenuFoodItems();
    void dailyRestockSuggestion();

    ~Manager() {}

    std::string option;
private:

};