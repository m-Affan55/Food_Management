#include "Order.h"

Order::Order(std::vector<FoodItem> orderedFood)
{
	this->orderedFood = orderedFood;
	
	for (int i = 0; i < orderedFood.size(); i++)
	{
		this->totalPrice += (orderedFood[i].price * orderedFood[i].quantity);
	}
}

Order::Order(std::vector<FoodItem> orderedFood, double totalPice)
{
	this->orderedFood = orderedFood;
	this->totalPrice = totalPice;
}

void Order::loadSalesOrdersFromFile(std::string filename)
{
	orders.clear();
	std::string record = "";

	std::vector<std::string> itemNamePriceQuantity;

	std::fstream file;
	file.open(filename, std::ios::in);
	while (getline(file, record))
	{
		std::vector<std::string> FileOrders = getItemsField(record, ',');
		std::vector<FoodItem> fOds;

		for (int i = 0; i < FileOrders.size() - 1; i++) //2 use hua h kyu k last wali total price h
		{
			itemNamePriceQuantity = getItemsField(FileOrders[i], ';');
			FoodItem f(itemNamePriceQuantity[0], stod(itemNamePriceQuantity[1]), stoi(itemNamePriceQuantity[2]));
			fOds.push_back(f);
		}
		
		if (!fOds.empty() && !FileOrders.empty()) {
			double total = stod(FileOrders.back());
			Order o(fOds, total);
			orders.push_back(o);
		}
	}
	file.close();
}

std::vector<std::string> Order::getItemsField(std::string record, char comma)
{
	std::vector<std::string> items;
	std::stringstream ss(record);
	std::string item;

	while (getline(ss, item, comma))
	{
		if (!item.empty())
		{
			items.push_back(item);
		}
	}
	return items;
}

std::vector<double> Order::getDoubleTypeItemsField(std::string record, char comma)
{
	std::vector<double> items;
	std::stringstream ss(record);
	std::string item;

	while (getline(ss, item, comma))
	{
		if (!item.empty())
		{
			items.push_back(stod(item));
		}
	}
	return items;
}
std::vector<int> Order::getIntTypeItemsField(std::string record, char comma)
{
	std::vector<int> items;
	std::stringstream ss(record);
	std::string item;

	while (getline(ss, item, comma))
	{
		if (!item.empty())
		{
			items.push_back(stoi(item));
		}
	}
	return items;
}

void Order::writeSaleOrdersToFile(std::string filename)
{
	std::string record;

	std::fstream file;
	file.open(filename, std::ios::out);
	for (int i = 0; i < orders.size(); i++)
	{
		record = "";
		for (int j = 0; j < orders[i].orderedFood.size(); j++)
		{
			record += orders[i].orderedFood[j].itemName;
			record += ';';
			record += std::to_string(orders[i].orderedFood[j].price);
			record += ';';
			record += std::to_string(orders[i].orderedFood[j].quantity);
			record += ",";
		}
		record += std::to_string(orders[i].totalPrice);
		record += '\n';
		file << record;
	}
	file.close();
}

std::vector<Order> Order::orders = {};