#pragma once
#include<iostream>
#include<string>
#include<vector>
#include<sstream>

#include"FoodItem.h"

class Order
{
public:
	static std::vector<Order> orders;
	static void loadSalesOrdersFromFile(std::string filename);
	static void writeSaleOrdersToFile(std::string filename);

	static std::vector<std::string> getItemsField(std::string record, char comma);
	static std::vector<int> getIntTypeItemsField(std::string record, char comma);
	static std::vector<double> getDoubleTypeItemsField(std::string record, char comma);

	Order(std::vector<FoodItem> orderedFood);
	Order(std::vector<FoodItem> orderedFood,double totalPice);

	std::vector<FoodItem> orderedFood;
	double totalPrice;
private:

};

