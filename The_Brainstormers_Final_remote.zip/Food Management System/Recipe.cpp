#include "Recipe.h"
#include<conio.h>

void Recipe::loadRecipeFromFile(std::string filename)
{
	recipes.clear();
	std::string record = "";

	std::fstream file;
	file.open(filename, std::ios::in);
	while (getline(file, record))
	{
		FileHandling get;
		std::string itemName = get.getField(record, 0);
		std::string ingredient = get.getField(record, 1);
		std::string step = get.getField(record, 2);

		std::vector<std::string> ing = getIngredientsField(ingredient, ';');
		std::vector<std::string> s = getIngredientsField(step, ';');

		Recipe recipe(ing,s,itemName);
		recipes.push_back(recipe);
	}
	file.close();
}

void Recipe::writeRecipeToFile(std::string filename)
{
	std::string record;

	std::fstream file;
	file.open(filename, std::ios::out);
	for (int i = 0; i < recipes.size(); i++)
	{
		record = "";
		record += recipes[i].itemName;
		record += ",";
		for (int j = 0; j < recipes[i].ingredients.size(); j++)
		{
			record += recipes[i].ingredients[j];
			if (j < recipes[i].ingredients.size() - 1)
			{
				record += ';';
			}	
		}
		record += ',';
		for (int j = 0; j < recipes[i].steps.size(); j++)
		{
			record += recipes[i].steps[j];
			if (j < recipes[i].steps.size() - 1)
			{
				record += ';';
			}	
		}
		record += "\n";
		file << record;
	}
	file.close();
}

std::vector<std::string> Recipe::getIngredientsField(std::string record, char comma)
{
	int commaCount = 0;
	std::string result;
	std::vector<std::string> ing;
	for (int i = 0; record[i] != '\0'; i++)
	{
		if(record[i]!=';')
			result += record[i];
		if (record[i] == comma || i==record.size()-1)
		{
			ing.push_back(result);
			result = "";
			continue;
		}
	}
	return ing;
}

std::vector<Recipe> Recipe::recipes = {};