#pragma once
#include<iostream>
#include<sstream>
#include<string>
#include<vector>

#include"FileHandling.h"

class Recipe
{
public:
	static std::vector<Recipe> recipes;
	static void loadRecipeFromFile(std::string filename);
	static void writeRecipeToFile(std::string filename);

	std::vector<std::string> ingredients;
	std::vector<std::string> steps;
	std::string itemName;
	
	Recipe(std::vector<std::string> ingredients, std::vector<std::string> steps, std::string itemname)
	{
		this->ingredients = ingredients;
		this->steps = steps;
		this->itemName = itemname;
	}
	static std::vector<std::string> getIngredientsField(std::string record, char comma);

private:

};

