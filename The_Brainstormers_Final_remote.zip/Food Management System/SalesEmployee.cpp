#include "SalesEmployee.h"
#include "PrintTitle.h"
#include <iomanip>
#include <vector>
#include<conio.h>

void SalesEmployee::SalesEmployeeMenu()
{
	std::string salesEmpChoice = "";
	do {
		system("cls");
		PrintTitle::printTitle();
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|        " << "\033[31m" << "Sales Employee Menu!" << "\033[32m" << "          |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "1. View Menu" << "\033[32m" << "             |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "2. Take Order" << "\033[32m" << "            |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|             " << "\033[31m" << "3. Sign Out" << "\033[32m" << "              |" << "\033[0m" << '\n';
		std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';

		if (!salesEmpChoice.empty() && salesEmpChoice != "1" && salesEmpChoice != "2" && salesEmpChoice != "3") {
			std::cout << "\033[32m" << "|        Select a valid option!        |" << "\033[0m" << '\n';
			std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		}
		else {
			std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
			std::cout << "\033[32m" << "|                                      |" << "\033[0m" << '\n';
		}
		std::cout << "\033[32m" << "+======================================+" << "\033[0m" << '\n';
		std::cout << "\033[31m" << "Enter your choice: " << "\033[0m";
		std::getline(std::cin, salesEmpChoice);
	} while (salesEmpChoice != "1" && salesEmpChoice != "2" && salesEmpChoice != "3");
	option = salesEmpChoice;
}

void SalesEmployee::TakeOrder()
{
	viewMenu();
	std::vector<FoodItem> currentOrder;
	StringValidator str;
	std::string s_size;
	int size = 0;

	PrintTitle::gotoxy(60, 0); std::cout << "\033[32m+======================================+\033[0m";
	PrintTitle::gotoxy(60, 1); std::cout << "\033[32m|            \033[31mTake an Order\033[32m             |\033[0m";
	PrintTitle::gotoxy(60, 2); std::cout << "\033[32m+======================================+\033[0m";
	PrintTitle::gotoxy(60, 3); std::cout << "\033[32m| \033[31mHow many different items? \033[32m           |\033[0m";
	PrintTitle::gotoxy(60, 4); std::cout << "\033[32m|                                      |\033[0m";
	PrintTitle::gotoxy(60, 5); std::cout << "\033[32m+======================================+\033[0m";

	PrintTitle::gotoxy(89, 3);
	std::getline(std::cin, s_size);
	while (str.stringNumberValidator(s_size) || s_size.empty()) {
		PrintTitle::gotoxy(61, 4); std::cout << "\033[34m Invalid number. Try again. \033[0m";
		PrintTitle::gotoxy(89, 3); std::cout << "         ";
		PrintTitle::gotoxy(89, 3);
		std::getline(std::cin, s_size);
	}
	size = stoi(s_size);
	PrintTitle::gotoxy(62, 4); std::cout << "                             ";

	for (int i = 0; i < size; i++)
	{
		std::string itemName;
		int itemIdx = -1;

		PrintTitle::gotoxy(60, 7 + (i * 4)); std::cout << "\033[32m+--------------------------------------+\033[0m";
		PrintTitle::gotoxy(60, 8 + (i * 4)); std::cout << "\033[32m| \033[31mItem #" << i + 1 << " Name: \033[32m                       |\033[0m";
		PrintTitle::gotoxy(60, 9 + (i * 4)); std::cout << "\033[32m| \033[31mQuantity: \033[32m                           |\033[0m";
		PrintTitle::gotoxy(60, 10 + (i * 4)); std::cout << "\033[32m+--------------------------------------+\033[0m";

		while (itemIdx == -1) {
			PrintTitle::gotoxy(60, 11 + (i * 4)); std::cout << "                            ";
			PrintTitle::gotoxy(76, 8 + (i * 4));
			std::getline(std::cin, itemName);
			for (size_t j = 0; j < FoodItem::foods.size(); ++j) {
				if (FoodItem::foods[j].itemName == itemName) {
					itemIdx = j;
					break;
				}
			}
			if (itemIdx == -1) {
				PrintTitle::gotoxy(60, 11 + (i * 4)); std::cout << "\033[34m      Item not found!               \033[0m";
				_getch();
				PrintTitle::gotoxy(76, 8 + (i * 4));
				std::cout << "                      ";
			}
		}

		std::string s_quantity;
		int quantity = 0;
		bool quantityOk = false;
		while (!quantityOk) {
			PrintTitle::gotoxy(72, 9 + (i * 4));
			std::getline(std::cin, s_quantity);
			if (str.stringNumberValidator(s_quantity) || s_quantity.empty()) {
				PrintTitle::gotoxy(62, 11 + (i * 4)); std::cout << "\033[34m    Invalid quantity!                \033[0m";
				PrintTitle::gotoxy(72, 9 + (i * 4)); std::cout << "                           ";
				continue;
			}
			quantity = stoi(s_quantity);
			if (quantity > FoodItem::foods[itemIdx].quantity) {
				PrintTitle::gotoxy(62, 11 + (i * 4)); std::cout << "\033[34m  Not enough stock! Av: " << FoodItem::foods[itemIdx].quantity << "  \033[0m";
				PrintTitle::gotoxy(72, 9 + (i * 4)); std::cout << "                           ";
			}
			else {
				quantityOk = true;
			}
		}

		FoodItem::foods[itemIdx].quantity -= quantity;
		currentOrder.push_back(FoodItem(FoodItem::foods[itemIdx].itemName, FoodItem::foods[itemIdx].price, quantity));
	}

	Order order(currentOrder);
	Order::orders.push_back(order);

	system("cls");
	std::cout << "\033[32m+====================================================+\033[0m" << '\n';
	std::cout << "\033[32m|                   \033[31mFinal Order\033[32m                      |\033[0m" << '\n';
	std::cout << "\033[32m+---------------------+----------------+-------------+\033[0m" << '\n';
	std::cout << "\033[32m| " << "\033[31m" << std::left << std::setw(19) << "Item" << "\033[32m" << " | " << "\033[31m" << std::setw(14) << "Quantity" << "\033[32m" << " | " << "\033[31m" << std::setw(11) << "Price" << "\033[32m" << " |" << '\n';
	std::cout << "\033[32m+---------------------+----------------+-------------+\033[0m" << '\n';
	for (const auto& item : currentOrder) {
		std::cout << "\033[32m| " << "\033[31m" << std::left << std::setw(19) << item.itemName << "\033[32m" << " | " << "\033[31m" << std::setw(14) << item.quantity << "\033[32m" << " | " << "\033[31m" << std::setw(11) << std::fixed << std::setprecision(2) << item.price * item.quantity << "\033[32m" << " |" << '\n';
	}
	std::cout << "\033[32m+---------------------+----------------+-------------+\033[0m" << '\n';
	std::cout << "\033[32m| " << std::left << std::setw(19) << " " << " | " << "\033[31m" << std::setw(14) << "Total" << "\033[32m" << " | " << "\033[31m" << std::setw(11) << std::fixed << std::setprecision(2) << order.totalPrice << "\033[32m" << " |" << '\n';
	std::cout << "\033[32m+---------------------+----------------+-------------+\033[0m" << '\n';
}

void SalesEmployee::viewMenu()
{
	Manager::viewMenuFoodItems();
}
