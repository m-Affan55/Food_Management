#pragma once
#include<iostream>
#include<string>
#include<limits>

#include"Manager.h"
#include"StringValidator.h"
#include"Order.h"

class SalesEmployee
{
public:
	void SalesEmployeeMenu();
	void TakeOrder();
	void viewMenu();

	std::string option;
private:

};

