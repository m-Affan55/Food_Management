#pragma once
#include<iostream>

class StringValidator
{
public:
	bool stringNumberValidator(std::string line)
	{
		int dotCount = 0;
		for (int i = 0; line[i] != '\0'; i++)
		{
			if (line[i] == '.')
				dotCount++;
			if (dotCount > 1)
				return false;
			if (line[i] == '0' || line[i] == '1' || line[i] == '2' || line[i] == '3' || line[i] == '4' ||
				line[i] == '5' || line[i] == '6' || line[i] == '7' || line[i] == '8' || line[i] == '9' || line[i]=='.')
			{
				return false;
			}
		}
		return true;
	}
};