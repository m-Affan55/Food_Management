#include "User.h"

User::User(std::string username, std::string password, std::string role)
{
	this->username = username;
	this->password = password;
	this->role = role;
}

User::User(std::string role)
{
	this->role = role;
}

User::User()
{
}

void User::loadUsersFromFile(std::string filename)
{
	users.clear();
	std::string record = "";

	std::fstream file;
	file.open(filename, std::ios::in);
	while (getline(file, record))
	{
		FileHandling get;
		std::string username = get.getField(record, 0);
		std::string password = get.getField(record, 1);
		std::string role     = get.getField(record, 2);
		User user(username, password, role);
		users.push_back(user);
	}
	file.close();
}

void User::writeUsersToFile(std::string filename)
{
	std::string record;

	std::fstream file;
	file.open(filename,std::ios::out);
	for (int i = 0; i < users.size(); i++)
	{
		record = "";
		record += users[i].username;
		record += ",";
		record += users[i].password;
		record += ",";
		record += users[i].role;
		record += "\n";
		file << record;
	}
	file.close();
}

std::vector<User> User::users = {};