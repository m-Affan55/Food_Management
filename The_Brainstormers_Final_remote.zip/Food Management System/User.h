#pragma once
#include<iostream>
#include<fstream>
#include<vector>
#include<string>

#include"FileHandling.h"

class User
{
public:
	static std::vector<User> users;
	static void loadUsersFromFile(std::string filename);
	static void writeUsersToFile(std::string filename);

	std::string username;
	std::string password;
	std::string role;

	User(std::string username, std::string password, std::string role);
	User(std::string role);
	User();
private:
	
};

