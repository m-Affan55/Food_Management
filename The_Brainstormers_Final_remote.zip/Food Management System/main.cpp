#include<iostream>
#include<string>
#include<conio.h>

#include"Login.h"
#include"User.h"
#include"Admin.h"
#include"Manager.h"
#include"Chef.h"
#include"SalesEmployee.h"

int main()
{
	bool exit = 0;
	std::string login = "";

	User user;

	while (!exit)
	{
		User::loadUsersFromFile("credentials.txt");
		FoodItem::loadRequestedFoodItemsFromFile("requests.txt");
		FoodItem::loadMenuFoodItemsFromFile("menu.txt");
		Recipe::loadRecipeFromFile("recipes.txt");
		Order::loadSalesOrdersFromFile("sales.txt");

		login = Login::login();
		if (login == "1")
		{
			user = Login::SignIn();
			//roles wise working k liye
			if (user.role == "Admin")
			{
				Admin admin;
				while (true)
				{
					system("cls");
					admin.AdminMenu();
					if (admin.option == "1")
					{
						admin.addUser();
						User::writeUsersToFile("credentials.txt");
						User::loadUsersFromFile("credentials.txt");
					}
					if (admin.option == "2")
					{
						admin.deleteUser();
						User::writeUsersToFile("credentials.txt");
						User::loadUsersFromFile("credentials.txt");
					}
					if (admin.option == "3")
					{
						admin.viewUsers();
					}
					if (admin.option == "4")
					{
						admin.viewLogs();
					}
					if (admin.option == "5")
					{
						break;
					}
					std::cout << "Press any key to continue!"<<'\n';
					char x = _getch();
				}
			}
			else if (user.role == "Manager")
			{
				Manager man;
				while (true)
				{
					system("cls");
					man.ManagerMenu();
					if (man.option == "1")
					{
						man.requestItem();
						FoodItem::writeRequestedFoodItemsToFile("requests.txt");
						FoodItem::loadRequestedFoodItemsFromFile("requests.txt");
					}
					if (man.option == "2")
					{
						man.increaseStock();
						FoodItem::writeMenuFoodItemsToFile("menu.txt");
						FoodItem::loadMenuFoodItemsFromFile("menu.txt");
					}
					if (man.option == "3")
					{
						man.viewRequestedFoodItems();
					}
					if (man.option == "4")
					{
						man.viewMenuFoodItems();
					}
					if (man.option == "5")
					{
						man.viewSalesReport();
					}
					if (man.option == "6")
					{
						man.dailyRestockSuggestion();
					}
					if (man.option == "7")
					{
						break;
					}
					std::cout << "Press any key to continue!" << '\n';
					char x = _getch();
				}
			}
			else if (user.role == "Chef")
			{
				Chef chef;
				while (true)
				{
					system("cls");
					chef.ChefMenu();
					if (chef.option == "1")
					{
						Manager::viewRequestedFoodItems();
					}
					if (chef.option == "2")
					{
						chef.AddRecipe();
						Recipe::writeRecipeToFile("recipes.txt");
						Recipe::loadRecipeFromFile("recipes.txt");
						FoodItem::writeMenuFoodItemsToFile("menu.txt");
						FoodItem::loadMenuFoodItemsFromFile("menu.txt");
						FoodItem::writeRequestedFoodItemsToFile("requests.txt");
						FoodItem::loadRequestedFoodItemsFromFile("requests.txt");
					}
					if (chef.option == "3")
					{
						chef.viewAllRecipes();
					}
					if (chef.option == "4")
					{
						chef.editRecipe();
						Recipe::writeRecipeToFile("recipes.txt");
						Recipe::loadRecipeFromFile("recipes.txt");
					}
					if (chef.option == "5")
					{
						break;
					}
					std::cout << "Press any key to continue!" << '\n';
					char x=_getch();
				}
			}
			else if (user.role == "Sales Employee")
			{
				SalesEmployee sale;
				while (true)
				{
					system("cls");
					sale.SalesEmployeeMenu();
					if (sale.option == "1")
					{
						Manager::viewMenuFoodItems();
					}
					if (sale.option == "2")
					{
						sale.TakeOrder();
						FoodItem::writeMenuFoodItemsToFile("menu.txt");
						FoodItem::loadMenuFoodItemsFromFile("menu.txt");
						Order::writeSaleOrdersToFile("sales.txt");
						Order::loadSalesOrdersFromFile("sales.txt");

					}
					if (sale.option == "3")
					{
						break;
					}
					std::cout << "Press any key to continue!" << '\n';
					char x = _getch();
				}
			}
			else if (user.role == "exit")
			{
				continue;
			}
		}
		//login par wapis janay k liye
		else if (login == "2")
		{
			break;
		}
	}
	return 0;
}