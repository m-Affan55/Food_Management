Assalam u ALaikum!
This has been made on visual studio so open in visual studio and make sure cpp extension for visual studio is installed.

I will highly suggest running on visual studio ide for checking we have created in on it but also done some changes so it can also run on vs code.

if any errors occur u can also clone from GitHub:
https://github.com/Muhammad-Farhan-Ali/BrainByte_Hackathon

We had put a lot of effort in it and hope u will like our application.
We have also created an exe file which can be ran without any editor or something so it can also be tested.

Regards!

The simple file is for visual studio code and the second file is for vs code as vs code uses Mingw and visual studio uses other compiler so this why 2 files are given

Type these to run in vs code

g++ main.cpp Admin.cpp User.cpp Manager.cpp Chef.cpp SalesEmployee.cpp Login.cpp FoodItem.cpp Recipe.cpp Order.cpp -o main

.\main.exe